#include <stdio.h>
#include "myProject.h"
int main(void)
{
printf("Chief name is 유빈\n");
printMyName1();
printMyName2();
printMyName3();
}
