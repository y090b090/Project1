#ifndef _ACCMAGGYRO_H_
#define _ACCMAGGYRO_H_



int acc(void);
int Gyro(void);
int Mag(void);

#endif
